CREATE USER IF NOT EXISTS 'alberto'@'%' IDENTIFIED BY 'alberto';

GRANT ALL PRIVILEGES ON alberto.* TO 'alberto'@'%' IDENTIFIED BY 'alberto';
